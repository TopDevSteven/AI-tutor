import './App.css';
import UserDashboard from './pages/user-dashboard-page/UserDashboard';

function App() {
  return (
    <div>
      {/* <Chatarea /> */}
      
      <UserDashboard />
    </div>
  );
}

export default App;
